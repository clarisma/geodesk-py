static const int ATTR_COUNT = 14;
static const char* ATTR_NAMES[] =
{
    "exclude_keys",
    "id",
    "keys",
    "limit",
    "linewise",
    "max_width",
    "mercator",
    "precision",
    "pretty",
    "save",
    "scale",
    "simplify",
    "sort_tags",
    "translate",
};