// Copyright (c) 2024 Clarisma / GeoDesk contributors
// SPDX-License-Identifier: LGPL-3.0-only

#pragma once

/*
#include "RTree.h"
#include "util/Arena.h"

template <typename IT>
class OmtTreeBuilder
{
public:
	OmtTreeBuilder(Arena& arena) : arena_(arena) {}

	RTree::Node<IT>* build(RTree::Node<IT> leafNodes, size_t count, RTree::Node<IT>* parentNodes);

private:
	Arena& arena_;
};
*/