// Copyright (c) 2023 Clarisma / GeoDesk contributors
// SPDX-License-Identifier: LGPL-3.0-only

#pragma once

class CliApplication
{
public:
	CliApplication();

	void run(int argc, char* argv[]);
};
