#include "TaskStatus.h"

const TaskStatus::Details TaskStatus::NORMAL_SHUTDOWN(TaskStatus::CODE_NORMAL_SHUTDOWN);
const TaskStatus::Details TaskStatus::ABORTED(TaskStatus::CODE_ABORTED);
const TaskStatus::Details TaskStatus::BAD_ALLOC(TaskStatus::CODE_BAD_ALLOC);
