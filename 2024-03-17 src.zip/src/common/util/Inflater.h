/*

// Copyright (c) 2024 Clarisma / GeoDesk contributors
// SPDX-License-Identifier: LGPL-3.0-only

#pragma once
#include <zlib.h>
#include <common/alloc/ReusableBlock.h>
#include <common/io/File.h>

class Inflater
{
private:
	ReusableBlock<
};

*/